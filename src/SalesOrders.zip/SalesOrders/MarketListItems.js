import { StyleSheet, Text, View, FlatList, SafeAreaView } from 'react-native';
import { useEffect } from 'react';
import { LinearGradient } from 'expo-linear-gradient';

const MarketListItems = ({ route }) => {
  const { MarketDetails } = route.params;
  const marketList = MarketDetails.listItems;

  useEffect(() => {
    console.log('Market Details:', MarketDetails);
  }, []);

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <Text style={styles.itemName}>{item.itemName}</Text>
      </View>
      <View style={styles.cardBody}>
        <View style={styles.detailRow}>
          <Text style={styles.label}>Quantity:</Text>
          <Text style={styles.value}>{item.qty}</Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={styles.label}>Weight:</Text>
          <Text style={styles.value}>{item.weight} kg</Text>
        </View>
        {item.offerPrice && (
          <View style={styles.detailRow}>
            <Text style={styles.label}>Offer Price:</Text>
            <Text style={styles.value}>₹{item.offerPrice}</Text>
          </View>
        )}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#2A6B57', '#3A8C73']} style={styles.header}>
        <Text style={styles.headerTitle}>{MarketDetails.marketName}</Text>
        <Text style={styles.headerSubtitle}>{MarketDetails.address}</Text>
      </LinearGradient>
      {marketList.length > 0 ? (
        <FlatList
          data={marketList}
          renderItem={renderItem}
          keyExtractor={(item) => item.itemId.toString()}
          contentContainerStyle={styles.listContent}
        />
      ) : (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No items available</Text>
        </View>
      )}
    </SafeAreaView>
  );
};

export default MarketListItems;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#e0e0e0',
    marginTop: 5,
  },
  listContent: {
    padding: 15,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 15,
    elevation: 3,
  },
  cardHeader: {
    backgroundColor: '#f0f0f0',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  itemName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  cardBody: {
    padding: 15,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  label: {
    fontSize: 16,
    color: '#666',
    fontWeight: '500',
  },
  value: {
    fontSize: 16,
    color: '#333',
    fontWeight: '600',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 18,
    color: '#666',
  },
});