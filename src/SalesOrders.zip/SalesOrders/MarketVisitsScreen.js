import { View, Text, StyleSheet, FlatList, TouchableOpacity, Animated } from 'react-native';
import { useEffect, useState } from 'react';
import { FontAwesome5, MaterialIcons, Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import axios from 'axios';
import BASE_URL from '../../config';
import { Dimensions } from 'react-native';

const { height,width } = Dimensions.get('window');

export default function MarketVisitsScreen() {
  const navigation = useNavigation();
  const [marketData, setMarketData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const pageSize = 10;
  const spinValue = new Animated.Value(0);

  useEffect(() => {
    getAllMarkets();
    Animated.loop(
      Animated.timing(spinValue, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      })
    ).start();
  }, []);

  const spin = spinValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  const getAllMarkets = () => {
    setLoading(true);
    axios({
      method: 'get',
      url: `${BASE_URL}product-service/getAllMarket?page=${page}&size=${pageSize}`,
    })
      .then((response) => {
        const { content, totalPages } = response.data;
        setMarketData(content);
        setTotalPages(totalPages);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching markets:', error.response);
        setLoading(false);
      });
  };

  useEffect(() => {
    getAllMarkets();
  }, [page]);

  const handlePrevPage = () => {
    if (page > 0 && !loading) {
      setPage(page - 1);
    }
  };

  const handleNextPage = () => {
    if (page < totalPages - 1 && !loading) {
      setPage(page + 1);
    }
  };

  const renderVisitItem = ({ item }) => (
    <View style={styles.visitItem}>
      <View style={styles.visitHeader}>
        <Text style={styles.visitMarket}>{item.marketName}</Text>
      </View>
      <View style={styles.visitDetails}>
        <View style={styles.visitRow}>
          <Ionicons name="location-outline" size={16} color="#777" style={styles.visitIcon} />
          <Text style={styles.visitDetailText}>{item.address}</Text>
        </View>
        <View style={styles.visitRow}>
          <Ionicons name="people-outline" size={16} color="#777" style={styles.visitIcon} />
          <Text style={styles.visitDetailText}>{item.leadName}</Text>
        </View>
        {item.notes && (
          <View style={styles.visitRow}>
            <MaterialIcons name="notes" size={16} color="#777" style={styles.visitIcon} />
            <Text style={styles.visitDetailText}>{item.notes}</Text>
          </View>
        )}
      </View>
      <View style={styles.visitActions}>
        <TouchableOpacity
          style={styles.visitButton}
          onPress={() => navigation.navigate('Market List Items', { MarketDetails: item })}
        >
          <Text style={styles.visitButtonText}>List Items</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.visitButton, {backgroundColor: '#2A6B57'}]}
          onPress={() => navigation.navigate('All Categories', { MarketDetails: item,type:"Market" })}
        >
          <Text style={styles.primaryButtonText}>Add market items</Text>
        </TouchableOpacity>

         <TouchableOpacity
          style={[styles.visitButton, {backgroundColor: '#0384d5'}]}
          onPress={() => navigation.navigate('Place Order', { MarketDetails: item,type:"Market" })}
        >
          <Text style={styles.primaryButtonText}>Place Order</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderLoader = () => (
    <View style={styles.loaderContainer}>
      <Animated.View style={[styles.loaderCircle, { transform: [{ rotate: spin }] }]} />
      <Text style={styles.loaderText}>Loading Items...</Text>
    </View>
  );

  const renderPagination = () => (
    <View style={styles.paginationContainer}>
      <TouchableOpacity
        style={[styles.paginationButton, page === 0 && styles.disabledButton]}
        onPress={handlePrevPage}
        disabled={page === 0 || loading}
      >
        <Ionicons
          name="chevron-back"
          size={20}
          color={page === 0 || loading ? '#a0a0a0' : '#fff'}
        />
        <Text style={[styles.paginationText, page === 0 && styles.disabledText]}>Previous</Text>
      </TouchableOpacity>
      <Text style={styles.pageInfo}>
        Page {page + 1} of {totalPages}
      </Text>
      <TouchableOpacity
        style={[styles.paginationButton, page >= totalPages - 1 && styles.disabledButton]}
        onPress={handleNextPage}
        disabled={page >= totalPages - 1 || loading}
      >
        <Text style={[styles.paginationText, page >= totalPages - 1 && styles.disabledText]}>Next</Text>
        <Ionicons
          name="chevron-forward"
          size={20}
          color={page >= totalPages - 1 || loading ? '#a0a0a0' : '#fff'}
        />
      </TouchableOpacity>
    </View>
  );

    function footer() {
    return (
      <View style={{ alignSelf: "center" }}>
        <Text>No more data Found </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {loading ? (
        renderLoader()
      ) : (
        <>
          <TouchableOpacity
            style={styles.scheduleButton}
            onPress={() => navigation.navigate('Add Market')}
          >
            <FontAwesome5 name="calendar-plus" size={16} color="#fff" style={styles.scheduleIcon} />
            <Text style={styles.scheduleButtonText}>Schedule New Visit</Text>
          </TouchableOpacity>
          {renderPagination()}
          <FlatList
            data={marketData}
            renderItem={renderVisitItem}
            keyExtractor={(item) => item.id}
            style={styles.visitsList}
             ListFooterComponent={footer}
                  ListFooterComponentStyle={styles.footerStyle}
          />
        </>
      )}
      <View style={styles.bottomPadding} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  visitsList: {
    padding: 15,
  },
  visitItem: {
    backgroundColor: '#fff',
    borderRadius: 5,
    marginBottom: 15,
    borderWidth: 0.6,
    borderColor: '#000',
  },
  visitHeader: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#808080',
  },
  visitMarket: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  visitDetails: {
    padding: 15,
  },
  visitRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  visitIcon: {
    marginRight: 8,
  },
  visitDetailText: {
    fontSize: 14,
    color: '#555',
    flex: 1,
  },
  visitActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    padding: 15,
    paddingTop: 5,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  visitButton: {
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 6,
    marginLeft: 8,
  },
  visitButtonText: {
    fontSize: 14,
    color: '#555',
  },
  primaryButton: {
    backgroundColor: '#2A6B57',
  },
  primaryButtonText: {
    color: '#fff',
    fontWeight: '500',
  },
  loaderContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    height: height / 1.5,
  },
  loaderCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 5,
    borderColor: '#4A90E2',
    borderTopColor: 'transparent',
    marginBottom: 10,
  },
  loaderText: {
    fontSize: 16,
    color: '#4A90E2',
    fontWeight: 'bold',
  },
  scheduleButton: {
    backgroundColor: '#2A6B57',
    borderRadius: 25,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 20,
    alignSelf: 'center',
    marginVertical: 20,
  },
  scheduleIcon: {
    marginRight: 8,
  },
  scheduleButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
  },
  paginationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 10,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  paginationButton: {
    flexDirection: 'row',
    backgroundColor: '#2A6B57',
    borderRadius: 8,
    padding: 10,
    alignItems: 'center',
    // flex: 1,
    marginHorizontal: 5,
    width:"auto"
  },
  disabledButton: {
    backgroundColor: '#a0a0a0',
  },
  paginationText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '500',
    marginHorizontal: 5,
  },
  disabledText: {
    color: '#e0e0e0',
  },
  pageInfo: {
    fontSize: 14,
    color: '#333',
    fontWeight: '500',
  },
  bottomPadding: {
    height: 20,
  },
  footerStyle:{
    marginBottom:100
  }
});