import React from "react";
import {View,Text} from "react-native"
import axios from "axios";


const StoreOrderedItems=()=>{
    return(
        <View>
            <Text>sdh</Text>
        </View>

    )
}

export default StoreOrderedItems